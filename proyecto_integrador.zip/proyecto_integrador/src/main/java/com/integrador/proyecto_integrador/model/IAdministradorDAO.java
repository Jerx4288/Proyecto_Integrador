package com.integrador.proyecto_integrador.model;

import org.springframework.data.repository.CrudRepository;

public interface IAdministradorDAO extends CrudRepository<Administrador,String>{

    
} 
