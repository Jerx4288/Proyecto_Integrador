package com.integrador.proyecto_integrador.model;

import org.springframework.data.repository.CrudRepository;

public interface ICitasDAO extends CrudRepository <Citas, String>{
    
}
