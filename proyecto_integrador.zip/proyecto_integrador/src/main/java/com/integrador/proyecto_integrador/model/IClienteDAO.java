package com.integrador.proyecto_integrador.model;

import org.springframework.data.repository.CrudRepository;

public interface IClienteDAO extends CrudRepository<Cliente,String> 
{

    
}